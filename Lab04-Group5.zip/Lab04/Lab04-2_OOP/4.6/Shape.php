<?php

abstract class Shape {
    abstract function getArea();
}

?>