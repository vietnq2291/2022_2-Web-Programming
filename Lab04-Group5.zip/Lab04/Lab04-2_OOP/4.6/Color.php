<?php
class Color {
    public $name;
}
?>